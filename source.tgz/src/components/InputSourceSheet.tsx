import { Cable, RadioTower, Tv, X } from 'lucide-react'
import { useEffect } from 'react'
import type { InputSource } from '../types/remote'
import { inputSourceLabels } from '../types/remote'

interface Props {
  open: boolean
  busy?: boolean
  onClose: () => void
  onSelect: (input: InputSource) => void
}

const sources: InputSource[] = ['sourceMenu', 'tv', 'hdmi', 'hdmi1', 'hdmi2', 'hdmi3', 'hdmi4']

export function InputSourceSheet({ open, busy, onClose, onSelect }: Props) {
  useEffect(() => {
    if (!open) return
    const handler = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose() }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [open, onClose])
  if (!open) return null

  return (
    <div className="sheet-backdrop" onPointerDown={onClose}>
      <div className="sheet" role="dialog" aria-modal="true" aria-labelledby="input-source-title" onPointerDown={(event) => event.stopPropagation()}>
        <div className="sheet-handle" />
        <button className="sheet-close" onClick={onClose} aria-label="Close"><X /></button>
        <h2 id="input-source-title">Choose input</h2>
        <p>Direct HDMI keys work on many Samsung Tizen models, but exact HDMI-key support varies by firmware. Source Menu is the safest fallback.</p>
        <div className="input-source-grid">
          {sources.map((source) => (
            <button key={source} disabled={busy} onClick={() => onSelect(source)}>
              {source === 'tv' ? <RadioTower /> : source === 'sourceMenu' ? <Tv /> : <Cable />}
              <span>{inputSourceLabels[source]}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
