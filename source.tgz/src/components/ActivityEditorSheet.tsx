import { ArrowDown, ArrowUp, Download, LoaderCircle, Plus, Trash2, X } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import type { Activity, ActivityStep, InputSource, RemoteCommand, TvApp, TvDevice } from '../types/remote'
import { inputSourceLabels, remoteCommandLabels } from '../types/remote'

interface Props {
  open: boolean
  activity?: Activity
  devices: TvDevice[]
  onClose: () => void
  onSave: (activity: Activity) => void
  onDelete: (id: string) => void
  onLoadApps: (deviceId: string) => Promise<TvApp[]>
}

const commandOptions = Object.entries(remoteCommandLabels) as Array<[RemoteCommand, string]>
const inputOptions = Object.entries(inputSourceLabels) as Array<[InputSource, string]>
const delayOptions = [0, 150, 300, 500, 750, 1000, 1500, 2500, 4000, 6000, 10_000]
const waitOptions = [500, 1000, 1500, 2500, 4000, 6000, 10_000, 15_000, 20_000, 30_000]

function createId() { return globalThis.crypto?.randomUUID?.() ?? `activity-${Date.now()}-${Math.random().toString(36).slice(2, 7)}` }
function defaultStep(type: ActivityStep['type']): ActivityStep {
  if (type === 'input') return { type: 'input', input: 'hdmi1', delayAfterMs: 1500 }
  if (type === 'app') return { type: 'app', app: { id: 'unselected', name: 'Select an app', platform: 'firetv' }, delayAfterMs: 1500 }
  if (type === 'wait') return { type: 'wait', waitMs: 2500, delayAfterMs: 0 }
  return { type: 'command', command: 'home', delayAfterMs: 300 }
}

export function ActivityEditorSheet({ open, activity, devices, onClose, onSave, onDelete, onLoadApps }: Props) {
  const [draft, setDraft] = useState<Activity | null>(null)
  const [appOptions, setAppOptions] = useState<TvApp[]>([])
  const [appsLoading, setAppsLoading] = useState(false)
  const [appsError, setAppsError] = useState('')

  useEffect(() => {
    if (!open) return
    setDraft(activity ? { ...activity, steps: activity.steps.map((step) => ({ ...step, ...(step.type === 'app' ? { app: { ...step.app } } : {}) })) } : {
      id: createId(), name: 'New activity', deviceId: devices.find((device) => device.favorite)?.id ?? devices[0]?.id ?? '', icon: 'play',
      steps: [{ type: 'command', command: 'powerOn', delayAfterMs: 1500 }, { type: 'command', command: 'home', delayAfterMs: 300 }],
    })
    setAppOptions([]); setAppsError('')
  }, [open, activity, devices])

  useEffect(() => {
    if (!open) return
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [open, onClose])

  const canSave = useMemo(() => Boolean(
    draft?.name.trim() && draft.deviceId && devices.some((device) => device.id === draft.deviceId) && draft.steps.length
    && draft.steps.every((step) => step.type !== 'app' || step.app.id !== 'unselected'),
  ), [draft, devices])

  if (!open || !draft) return null

  const loadApps = async () => {
    if (!draft.deviceId || appsLoading) return
    setAppsLoading(true); setAppsError('')
    try { setAppOptions(await onLoadApps(draft.deviceId)) }
    catch (error) { setAppsError(error instanceof Error ? error.message : 'Could not load apps') }
    finally { setAppsLoading(false) }
  }

  const updateStep = (index: number, step: ActivityStep) => setDraft((current) => current ? { ...current, steps: current.steps.map((item, stepIndex) => stepIndex === index ? step : item) } : current)
  const patchDelay = (step: ActivityStep, delayAfterMs: number): ActivityStep => ({ ...step, delayAfterMs } as ActivityStep)
  const moveStep = (index: number, direction: -1 | 1) => {
    setDraft((current) => {
      if (!current) return current
      const target = index + direction
      if (target < 0 || target >= current.steps.length) return current
      const steps = [...current.steps]
      ;[steps[index], steps[target]] = [steps[target], steps[index]]
      return { ...current, steps }
    })
  }
  const removeStep = (index: number) => setDraft((current) => current ? { ...current, steps: current.steps.filter((_, stepIndex) => stepIndex !== index) } : current)
  const save = () => { if (!canSave) return; onSave({ ...draft, name: draft.name.trim() }); onClose() }
  const removeActivity = () => { if (!activity || !window.confirm(`Delete “${activity.name}”?`)) return; onDelete(activity.id); onClose() }

  return (
    <div className="sheet-backdrop" onPointerDown={onClose}>
      <div className="sheet sheet--tall" role="dialog" aria-modal="true" aria-labelledby="activity-editor-title" onPointerDown={(event) => event.stopPropagation()}>
        <div className="sheet-handle" /><button className="sheet-close" onClick={onClose} aria-label="Close"><X /></button>
        <h2 id="activity-editor-title">{activity ? 'Edit activity' : 'Create activity'}</h2>
        <p>Mix remote commands, explicit HDMI inputs, app launches, and waits. Steps run top-to-bottom.</p>

        <div className="form-stack">
          <label><span>Name</span><input value={draft.name} maxLength={50} onChange={(event) => setDraft({ ...draft, name: event.target.value })} /></label>
          <label><span>Remote</span><select value={draft.deviceId} onChange={(event) => { setDraft({ ...draft, deviceId: event.target.value }); setAppOptions([]); setAppsError('') }}><option value="">Select a device…</option>{devices.map((device) => <option value={device.id} key={device.id}>{device.name} · {device.room}</option>)}</select></label>
          <label><span>Icon</span><select value={draft.icon} onChange={(event) => setDraft({ ...draft, icon: event.target.value as Activity['icon'] })}><option value="play">Play / movie</option><option value="tv">Television</option><option value="game">Gaming</option><option value="music">Music</option></select></label>
        </div>

        <div className="macro-heading"><strong>Steps</strong><span>{draft.steps.length}</span></div>
        <div className="macro-steps">
          {draft.steps.map((step, index) => {
            const availableApps = step.type === 'app' && !appOptions.some((app) => app.id === step.app.id) && step.app.id !== 'unselected' ? [step.app, ...appOptions] : appOptions
            return (
              <div className="macro-step macro-step--typed" key={`${index}-${step.type}`}>
                <span className="macro-step__number">{index + 1}</span>
                <div className="macro-step__fields">
                  <select aria-label={`Step ${index + 1} type`} value={step.type} onChange={(event) => updateStep(index, defaultStep(event.target.value as ActivityStep['type']))}>
                    <option value="command">Remote command</option><option value="input">TV input / HDMI</option><option value="app">Launch app</option><option value="wait">Wait</option>
                  </select>

                  {step.type === 'command' && <select aria-label={`Step ${index + 1} command`} value={step.command} onChange={(event) => updateStep(index, { ...step, command: event.target.value as RemoteCommand })}>{commandOptions.map(([command, label]) => <option key={command} value={command}>{label}</option>)}</select>}
                  {step.type === 'input' && <select aria-label={`Step ${index + 1} input`} value={step.input} onChange={(event) => updateStep(index, { ...step, input: event.target.value as InputSource })}>{inputOptions.map(([input, label]) => <option key={input} value={input}>{label}</option>)}</select>}
                  {step.type === 'app' && <div className="macro-app-row">
                    <select aria-label={`Step ${index + 1} app`} value={step.app.id} onChange={(event) => { const app = availableApps.find((item) => item.id === event.target.value); if (app) updateStep(index, { ...step, app }) }}>
                      <option value="unselected">Select an app…</option>{availableApps.map((app) => <option key={app.id} value={app.id}>{app.name} · {app.platform === 'samsung' ? 'Samsung' : 'Fire TV'}</option>)}
                    </select>
                    <button type="button" onClick={() => void loadApps()} disabled={appsLoading || !draft.deviceId} title="Load apps from TV">{appsLoading ? <LoaderCircle className="spin" /> : <Download />}</button>
                  </div>}
                  {step.type === 'wait' && <select aria-label={`Step ${index + 1} wait`} value={step.waitMs} onChange={(event) => updateStep(index, { ...step, waitMs: Number(event.target.value) })}>{waitOptions.map((delay) => <option value={delay} key={delay}>Wait {delay / 1000}s</option>)}</select>}

                  {step.type !== 'wait' && <select aria-label={`Delay after step ${index + 1}`} value={step.delayAfterMs ?? 300} onChange={(event) => updateStep(index, patchDelay(step, Number(event.target.value)))}>{delayOptions.map((delay) => <option value={delay} key={delay}>{delay === 0 ? 'No delay after' : `${delay / 1000}s after`}</option>)}</select>}
                  {step.type === 'app' && appsError && <small className="macro-error">{appsError}</small>}
                </div>
                <div className="macro-step__actions">
                  <button onClick={() => moveStep(index, -1)} disabled={index === 0} aria-label={`Move step ${index + 1} up`}><ArrowUp /></button>
                  <button onClick={() => moveStep(index, 1)} disabled={index === draft.steps.length - 1} aria-label={`Move step ${index + 1} down`}><ArrowDown /></button>
                  <button onClick={() => removeStep(index)} disabled={draft.steps.length === 1} aria-label={`Delete step ${index + 1}`}><Trash2 /></button>
                </div>
              </div>
            )
          })}
        </div>

        <button className="outline-card outline-card--compact" onClick={() => setDraft({ ...draft, steps: [...draft.steps, defaultStep('command')] })}><Plus /><span><strong>Add step</strong><small>Command, HDMI input, app launch, or wait</small></span></button>
        <div className="sheet-actions sheet-actions--with-delete">{activity ? <button className="button-delete" onClick={removeActivity}><Trash2 /> Delete</button> : <span />}<button className="button-primary" onClick={save} disabled={!canSave}>Save activity</button></div>
      </div>
    </div>
  )
}
