import { Gamepad2, Music, Pencil, Play, Plus, Tv } from 'lucide-react'
import type { Activity, TvDevice } from '../types/remote'

interface Props {
  activities: Activity[]
  devices: TvDevice[]
  onRun: (activity: Activity) => void
  onAdd: () => void
  onEdit: (activity: Activity) => void
  running?: boolean
}

const icons = { play: Play, tv: Tv, game: Gamepad2, music: Music }

export function ActivitiesView({ activities, devices, onRun, onAdd, onEdit, running }: Props) {
  return (
    <section className="content-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">ONE-TAP SETUPS</p>
          <h1>Activities</h1>
          <p>Build one-tap routines with power, HDMI inputs, app launches, navigation, and timed waits.</p>
        </div>
        <button className="icon-primary" onClick={onAdd} aria-label="Create activity"><Plus /></button>
      </div>

      <div className="activity-list">
        {activities.map((activity) => {
          const Icon = icons[activity.icon]
          const target = devices.find((device) => device.id === activity.deviceId)
          return (
            <article className="activity-card activity-card--split" key={activity.id}>
              <button className="activity-card__run" onClick={() => onRun(activity)} disabled={running || !target}>
                <div className="activity-icon"><Icon /></div>
                <span>
                  <strong>{activity.name}</strong>
                  <small>{target?.name ?? 'Missing device'} · {activity.steps.length} {activity.steps.length === 1 ? 'step' : 'steps'}</small>
                </span>
                <Play />
              </button>
              <button className="activity-card__edit" onClick={() => onEdit(activity)} aria-label={`Edit ${activity.name}`}><Pencil /></button>
            </article>
          )
        })}
        {!activities.length && <div className="empty-card">No activities yet. Create a one-tap setup for movie night, gaming, TV, or music.</div>}
      </div>

      <button className="coming-card coming-card--button" onClick={onAdd}>
        <Plus />
        <div><strong>Create custom activity</strong><span>Mix commands, HDMI inputs, apps, waits, and per-step timing.</span></div>
      </button>
    </section>
  )
}
