import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp } from 'lucide-react'
import type { RemoteCommand } from '../types/remote'

interface Props {
  onCommand: (command: RemoteCommand) => void
  disabled?: boolean
}

export function DPad({ onCommand, disabled }: Props) {
  return (
    <div className="dpad" aria-label="Directional controls">
      <button disabled={disabled} className="dpad__button dpad__up" onClick={() => onCommand('up')} aria-label="Up"><ChevronUp /></button>
      <button disabled={disabled} className="dpad__button dpad__left" onClick={() => onCommand('left')} aria-label="Left"><ChevronLeft /></button>
      <button disabled={disabled} className="dpad__select" onClick={() => onCommand('select')} aria-label="Select">OK</button>
      <button disabled={disabled} className="dpad__button dpad__right" onClick={() => onCommand('right')} aria-label="Right"><ChevronRight /></button>
      <button disabled={disabled} className="dpad__button dpad__down" onClick={() => onCommand('down')} aria-label="Down"><ChevronDown /></button>
    </div>
  )
}
