export type DeviceKind = 'samsung' | 'firetv' | 'combo'
export type ConnectionState = 'connected' | 'connecting' | 'disconnected' | 'error'
export type SamsungTransport = 'direct' | 'bridge'

export type RemoteCommand =
  | 'power'
  | 'powerOn'
  | 'powerOff'
  | 'home'
  | 'back'
  | 'menu'
  | 'up'
  | 'down'
  | 'left'
  | 'right'
  | 'select'
  | 'volumeUp'
  | 'volumeDown'
  | 'mute'
  | 'channelUp'
  | 'channelDown'
  | 'previousChannel'
  | 'guide'
  | 'info'
  | 'playPause'
  | 'play'
  | 'pause'
  | 'stop'
  | 'rewind'
  | 'fastForward'
  | 'input'
  | 'digit0'
  | 'digit1'
  | 'digit2'
  | 'digit3'
  | 'digit4'
  | 'digit5'
  | 'digit6'
  | 'digit7'
  | 'digit8'
  | 'digit9'

export type InputSource = 'sourceMenu' | 'tv' | 'hdmi' | 'hdmi1' | 'hdmi2' | 'hdmi3' | 'hdmi4'

export interface FireRemoteCertificate {
  key: string
  cert: string
}

export interface TvApp {
  id: string
  name: string
  platform: 'samsung' | 'firetv'
  appId?: string
  appType?: string | number
  packageName?: string
  deepLink?: string
  installed?: boolean
}

export interface DeviceLiveState {
  reachable: boolean
  powered?: boolean
  volume?: number
  currentApp?: string
  inputSource?: string
  mode?: string
  detail?: string
  updatedAt: number
}

export interface BridgeConfig {
  url: string
  token: string
}

export interface BaseDevice {
  id: string
  name: string
  room: string
  kind: DeviceKind
  host?: string
  macAddress?: string
  connection: ConnectionState
  lastSeen?: number
  favorite?: boolean
  favoriteAppIds?: string[]
}

export interface SamsungDevice extends BaseDevice {
  kind: 'samsung'
  port?: 8001 | 8002
  token?: string
  transport?: SamsungTransport
  bridgeUrl?: string
  bridgeToken?: string
}

export interface FireTvDevice extends BaseDevice {
  kind: 'firetv'
  port?: number
  pairingMode?: 'remote' | 'adb'
  bridgeUrl?: string
  bridgeToken?: string
  remoteCertificate?: FireRemoteCertificate
  remotePairingPort?: number
  remotePort?: number
}

export interface ComboDevice extends BaseDevice {
  kind: 'combo'
  samsungDeviceId: string
  fireTvDeviceId: string
}

export type TvDevice = SamsungDevice | FireTvDevice | ComboDevice

interface ActivityStepBase {
  delayAfterMs?: number
}

export interface ActivityCommandStep extends ActivityStepBase {
  type: 'command'
  command: RemoteCommand
}

export interface ActivityInputStep extends ActivityStepBase {
  type: 'input'
  input: InputSource
}

export interface ActivityAppStep extends ActivityStepBase {
  type: 'app'
  app: TvApp
}

export interface ActivityWaitStep extends ActivityStepBase {
  type: 'wait'
  waitMs: number
}

export type ActivityStep = ActivityCommandStep | ActivityInputStep | ActivityAppStep | ActivityWaitStep

export interface Activity {
  id: string
  name: string
  deviceId: string
  icon: 'play' | 'tv' | 'game' | 'music'
  steps: ActivityStep[]
}

export interface CommandResult {
  ok: boolean
  command: RemoteCommand
  message?: string
}

export interface PairingResult {
  ok: boolean
  certificate?: FireRemoteCertificate
  message?: string
}

export interface TvRemoteAdapter {
  connect(): Promise<void>
  disconnect(): Promise<void>
  send(command: RemoteCommand): Promise<CommandResult>
  sendText(text: string): Promise<CommandResult>
  listApps?(): Promise<TvApp[]>
  launchApp?(app: TvApp): Promise<void>
  setInput?(input: InputSource): Promise<void>
  getState?(): Promise<DeviceLiveState>
  pair?(code: string): Promise<PairingResult>
}

export const inputSourceLabels: Record<InputSource, string> = {
  sourceMenu: 'Source menu',
  tv: 'Live TV',
  hdmi: 'HDMI / cycle',
  hdmi1: 'HDMI 1',
  hdmi2: 'HDMI 2',
  hdmi3: 'HDMI 3',
  hdmi4: 'HDMI 4',
}

export const remoteCommandLabels: Record<RemoteCommand, string> = {
  power: 'Power toggle',
  powerOn: 'Power on',
  powerOff: 'Power off',
  home: 'Home',
  back: 'Back',
  menu: 'Menu',
  up: 'Up',
  down: 'Down',
  left: 'Left',
  right: 'Right',
  select: 'OK / Select',
  volumeUp: 'Volume up',
  volumeDown: 'Volume down',
  mute: 'Mute',
  channelUp: 'Channel up',
  channelDown: 'Channel down',
  previousChannel: 'Previous channel',
  guide: 'Guide',
  info: 'Info',
  playPause: 'Play / pause',
  play: 'Play',
  pause: 'Pause',
  stop: 'Stop',
  rewind: 'Rewind',
  fastForward: 'Fast forward',
  input: 'Input / source menu',
  digit0: '0',
  digit1: '1',
  digit2: '2',
  digit3: '3',
  digit4: '4',
  digit5: '5',
  digit6: '6',
  digit7: '7',
  digit8: '8',
  digit9: '9',
}
